import EventToCalendar from './eventToCalendar'
let elem  = document.querySelector('#parent')
import google from './providers/google'

let addToCalendar = new EventToCalendar(elem, {
  providers: [google],
  template: '<ul></ul>',
  details:{
    title:'title',
    description:'description',
    startDate:'2019-02-03',
    endDate:'2019-02-04',
    location:'HERE',
    guests:[
      'guest1@here.ro',
      'guest2@here.ro',
      'guest3@here.ro'
    ]
  }
})

